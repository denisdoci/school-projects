package edu.uic.denisdoci.doci2proj1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.net.Uri;
import android.widget.TextView;


public class proj1MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proj1_main);

    }

    //this is a function that is the on action
    //of phone button
    public void startDialer(View v)
    {
        //start the child dialer activity with key 1 and wait for result
        Intent intent = new Intent(proj1MainActivity.this, dialerActivity.class);
        startActivityForResult(intent,1);
    }

    //this function is the on action of
    //the link button
    public void goToDeveloper(View v)
    {
        // go to url function
        goToUrl("https://developer.android.com/index.html");
    }

    private void goToUrl (String url) {
        //parse the url for format and variable change
        Uri uriUrl = Uri.parse(url);
        //launch browser
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //textview is initially invisible because there is no message
        //get that text view
        TextView phoneText = (TextView) findViewById(R.id.recievedMessage);
        super.onActivityResult(requestCode, resultCode, data);
        //switch on request code
        switch(requestCode) {
            //if  it is the dialer activity
            case (1) : {
                // if the activity results in an ok return
                // ie the phone number is accepted
                if (resultCode == dialerActivity.RESULT_OK) {

                    //get the return value with the key number returned
                    String returnValue = data.getStringExtra("numberReturned");

                    //with that value open up the dialer
                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    //preload the dialer with the parsed number
                    intent.setData(Uri.parse("tel:"+returnValue));
                    startActivity(intent);
                    //set the text to found and the number and make visible
                    phoneText.setText("Found number : "+returnValue);
                    phoneText.setVisibility(View.VISIBLE);
                }
                else{
                    //error message could not find number and make text visable
                    phoneText.setText("Could not find number");
                    phoneText.setVisibility(View.VISIBLE);
                }
                break;
            }
        }
    }
}
