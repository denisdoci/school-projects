/*
1. There are 10 instructions required to execute the program.

2. The index variable is stored in the %ebx register and set to a value of 25 in main. Then it is subl(subtracted) by one each time the loop runs. 

3. Since "January has had crazy weather in Chicago this year,” is a string literal, it is not stored on the stack. Rather, it is stored in the read-only label .LC0. This is accessed later when the code writes the address of the string literal into a register. 

//------------------   4   ---------------------//
//— - - - - - - Info on registers from GDB- - - //
//- - - - - After 14 iterations of i- - - - - -//
//- - - - - Break point set at printf() - - - //

rax            0x33	51
rbx            0x0	0
rcx            0x400	1024
rdx            0x7ffff7dd59f0	140737351866864
rsi            0x7ffff7ff7000	140737354100736
rdi            0x0	0
rbp            0x7fffffffea60	0x7fffffffea60
rsp            0x7fffffffea50	0x7fffffffea50
r8             0x7ffff7fe6740	140737354032960
r9             0x0	0
r10            0x7fffffffe0c0	140737488347328
r11            0x246	582
r12            0x400440	4195392
r13            0x7fffffffeb40	140737488350016
r14            0x0	0
r15            0x0	0
rip            0x40053d	0x40053d <main+17>
eflags         0x287	[ CF PF SF IF ]
cs             0xe033	57395
ss             0xe02b	57387
ds             0x0	0
es             0x0	0
fs             0x0	0
gs             0x0	0
*/
#include <stdio.h>

int main()
{
  int i;

  for (i=0; i<25; i++){
  printf("\nJanuary has had crazy weather in Chicago this year");
  }
}
