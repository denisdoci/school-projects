#include <stdio.h>

int problem2(long int *x, long int *n)
{
  long int mask;
  long int r;
  mask = *x >> 63;
  r = ~*x & mask;
  r = r + (*x & ~mask);
  r = r >> (*n + ~0);
  r = !r;
  return r;
}

int main()
{
  long int x;
  long int n;

  printf("\nEnter a number x: ");
  scanf(" %ld", &x);
  printf("\nEnter n-bit value: ");
  scanf(" %ld", &n);
  printf("\nFunction (problem 2) returns: %d \n", problem2(&x, &n));
}
