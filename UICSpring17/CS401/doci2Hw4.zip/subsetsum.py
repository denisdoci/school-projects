import sys
import time
start_time = time.time()

outputList = []


outputIndex = []

minList = 0

minSize = 1000

numLists = 0

lexfirstindex = []

tempListSize = 0
"""
    def display(v):
    for i in range( 0, len(v)):
    print(v[i], end=" ")
    print("\n")
    """


def output(a, i, sum, dp, k):
    global minList
    global minSize
    global outputIndex
    global outputList
    global numLists
    global tempListSize
    
    if (i == 0 and sum != 0 and dp[0][sum]):
        if(k < minSize):
            minList = 1
            minSize = k
        if(k == minSize):
            minList += 1
        numLists += 1
        k = 0
        return
    
    if (i == 0 and sum == 0):
        if(k < minSize):
            minList = 1
            minSize = k
        if(k == minSize):
            minList += 1
        numLists += 1
        k=0
        return
    
    if dp[i - 1][sum]:
        #b = list(p)
        #m = list(l)
        #k = 0
        output(a, i - 1, sum, dp,k)
    
    if (sum >= a[i] and dp[i - 1][sum - a[i]]):
        #l.append(i)
        #p.append(a[i])
        k += 1
        output(a, i - 1, sum - a[i], dp,k)

def find(a, sum):
    if (len(a) == 0 or sum < 0):
        return
    dp = [[False for x in range(sum+1)] for y in range(len(a))]

for i in range(0, len(a)):
    dp[i][0] = True;
    
    for i in range (1,sum + 1):
        if a[0] == i:
            dp[0][i] = True
        else:
            dp[0][i] = False
    k = []
    for i in range(1, len(a)):
        for j in range( 1, sum + 1):
            if (dp[i-1][j]) :
                dp[i][j] = True;
            elif (j >= a[i] and dp[i-1][j-a[i]]):
                dp[i][j] = True;
            else:
                dp[i][j] = False
if dp[len(a) - 1][sum] == True:
    print("Feasible for sum ", sum)
    else:
        print("Not Feasible for sum ", sum)
#l = []
#p = []
return output(a, len(a) - 1, sum, dp, 0)

def main(args):
    file = args[2]
    nmax = int(args[0])
    target = int(args[1])
    with open(file, 'r') as input_file:
        input_list = [tuple(i.split()) for i in input_file]
    integerArray, stringArray = zip(*input_list)

integerArray = integerArray[:nmax]
    stringArray = stringArray[:nmax]
    
    integerArray = [int(i) for i in integerArray]
    print(integerArray)
    print(stringArray)
    
    find(integerArray, target)
    print('Number of distinct subsets ', end='')
    print(numLists)
    print('Size of smallest satisfying subset: ', end='')
    print(minSize)
    print('Number of min-sized satisfying subsets: ', end='')
    print(minList)
    print ('lexicographically first subset not implemented')
#print("List of sums", end= '')
#print(outputList)
#print("List of indeces", end= '')
#print(outputIndex)
#print("--- %s seconds ---" % (time.time() - start_time))


#outputIndex.sort(key=len)
#outputList.sort(key=len)



if __name__ == "__main__":
    main(sys.argv[1:])
