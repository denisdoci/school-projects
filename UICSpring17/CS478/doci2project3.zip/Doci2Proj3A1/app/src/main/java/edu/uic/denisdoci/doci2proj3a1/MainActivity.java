package edu.uic.denisdoci.doci2proj3a1;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

//some of this is taken from prof. ugo buy's
//example on permissions with broadcast receivers

public class MainActivity extends AppCompatActivity {

    private static final String TOAST_INTENT_BASEBALL = "Baseball";
    private static final String TOAST_INTENT_BASKETBALL = "Basketball";



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void onResume() {
        super.onResume()  ;
        if (ContextCompat.checkSelfPermission(this, "edu.uic.cs478.project3") !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{"edu.uic.cs478.project3"}, 0);
        }
    }
    protected void sendBaseballIntent(View v)
    {


        int permissionCheck	= ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.project3);
        if	(PackageManager.PERMISSION_GRANTED	==	permissionCheck)	{
        /*Do operation*/
            Intent aIntent = new Intent(TOAST_INTENT_BASEBALL);
            aIntent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
            sendOrderedBroadcast(aIntent, null);
        }
        else{
        /*	Prompt user for	permission	now	*/
            Toast.makeText(MainActivity.this, "BUMMER: No Permission :-(",
                    Toast.LENGTH_SHORT).show();
        }

    }

    protected void sendBasketballIntent(View v)
    {
        int permissionCheck	= ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.project3);
        if	(PackageManager.PERMISSION_GRANTED	==	permissionCheck)	{
        /*Do operation*/
            Intent aIntent = new Intent(TOAST_INTENT_BASKETBALL);
            aIntent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
            sendOrderedBroadcast(aIntent, null);
        }
        else{
        /*	Prompt user for	permission	now	*/
            Toast.makeText(MainActivity.this, "BUMMER: No Permission :-(",
                    Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 0: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    Toast.makeText(MainActivity.this, "permissions granted ",
                            Toast.LENGTH_SHORT).show();


                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this, "BUMMER: No Permission :-(", Toast.LENGTH_LONG).show() ;
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
}
