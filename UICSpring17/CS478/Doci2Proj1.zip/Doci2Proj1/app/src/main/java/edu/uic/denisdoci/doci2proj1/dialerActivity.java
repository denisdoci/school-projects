package edu.uic.denisdoci.doci2proj1;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * Created by denisdoci on 2/4/17.
 */

public class dialerActivity extends Activity{

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Get the view from new_activity.xml

        setContentView(R.layout.dialerlayout);

    }

    // this function is the on action of hitting the
    // DIAL button
    public void openDialer(View v)
    {
        // possible formats found
        Boolean matchesFormatOne, matchesFormatTwo, matchesFormatThree;

        // get user text
        EditText phoneText = (EditText)findViewById(R.id.number);

        // change user text to a string
        String userEnteredNumber = phoneText.getText().toString();


        //run a check with our boolean functions
        //to determine if any of the format required
        //to open the dialer
        matchesFormatOne = checkFormatOne(userEnteredNumber);
        matchesFormatTwo = checkFormatTwo(userEnteredNumber);
        matchesFormatThree = checkFormatThree(userEnteredNumber);

        //“(xxx) yyy-zzzz”
        if(matchesFormatTwo)
        {
            //a match is found
            String matchedPattern;

            // this portion is to extract the part that complies to the format
            // via regex
            Pattern pattern = Pattern.compile("\\(\\d{3}\\)\\s\\d{3}-\\d{4}");
            Matcher matcher = pattern.matcher(userEnteredNumber);
            if(matcher.find())
            {
                matchedPattern = matcher.group();

            }
            else
            {
                matchedPattern = userEnteredNumber;
            }

            //extract just the digits and get rid of
            // (,), and - characters
            char[] firstPortion = new char[3];
            matchedPattern.getChars(1,4,firstPortion,0);

            char[] secondPortion = new char[3];
            matchedPattern.getChars(6,9,secondPortion,0);

            char[] thirdPortion = new char[4];
            matchedPattern.getChars(10,14,thirdPortion,0);

            //combine extracted digits
            String preSend1 = new String(firstPortion);
            String preSend2 = new String(secondPortion);
            String preSend3 = new String(thirdPortion);
            String finalSend = preSend1+preSend2+preSend3;

            //return the result ok along with the extracted
            //digits to the main activity
            Intent resultIntent = new Intent();
            resultIntent.putExtra("numberReturned", finalSend);
            setResult(Activity.RESULT_OK, resultIntent);
            phoneText.setText(finalSend);
            finish();

        }

        //“(xxx)yyy-zzzz”

        //same process just different extractions
        else if(matchesFormatThree)
        {
            String matchedPattern;
            Pattern pattern = Pattern.compile("\\(\\d{3}\\)\\s\\d{3}-\\d{4}");
            Matcher matcher = pattern.matcher(userEnteredNumber);
            if(matcher.find())
            {
                matchedPattern = matcher.group();

            }
            else
            {
                matchedPattern = userEnteredNumber;
            }

            char[] firstPortion = new char[3];
            matchedPattern.getChars(1,4,firstPortion,0);

            char[] secondPortion = new char[3];
            matchedPattern.getChars(5,8,secondPortion,0);

            char[] thirdPortion = new char[4];
            matchedPattern.getChars(9,13,thirdPortion,0);

            String preSend1 = new String(firstPortion);
            String preSend2 = new String(secondPortion);
            String preSend3 = new String(thirdPortion);
            String finalSend = preSend1+preSend2+preSend3;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("numberReturned", finalSend);
            setResult(Activity.RESULT_OK, resultIntent);
            phoneText.setText(finalSend);
            finish();

        }

        //“yyy-zzzz”
        // same process but different extraction
        // this portion NEEDS to be at the end
        // because the format is actually a
        // sub format of the previous regexes
        else if(matchesFormatOne)
        {
            String matchedPattern;
            Pattern pattern = Pattern.compile("\\d{3}-\\d{4}");
            Matcher matcher = pattern.matcher(userEnteredNumber);
            if(matcher.find())
            {
                matchedPattern = matcher.group();

            }
            else
            {
                matchedPattern = userEnteredNumber;
            }

            char[] firstPortion = new char[3];
            matchedPattern.getChars(0,3,firstPortion,0);
            char[] secondPortion = new char[4];
            matchedPattern.getChars(4,8,secondPortion,0);
            String preSend1 = new String(firstPortion);
            String preSend2 = new String(secondPortion);
            String finalSend = preSend1+preSend2;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("numberReturned", finalSend);
            setResult(Activity.RESULT_OK, resultIntent);
            phoneText.setText(finalSend
            );
            finish();

        }

        else{
            //phone doesn't match the format go back
            //send error message
            Intent resultIntent = new Intent();
            setResult(Activity.RESULT_CANCELED, resultIntent);
            finish();
        }
    }

    //“yyy-zzzz”
    //Function: takes in user string sees if it matches format
    private boolean checkFormatOne(String userEnteredNumber)
    {
        if(userEnteredNumber.matches(".*(\\d{3}-\\d{4}).*"))
        {
            return true;
        }
        return false;
    }

    //“(xxx) yyy-zzzz”
    //Function: takes in user string sees if it matches format
    private boolean checkFormatTwo(String userEnteredNumber)
    {
        if(userEnteredNumber.matches(".*(\\(\\d{3}\\)\\s\\d{3}-\\d{4}).*"))
        {
            return true;
        }
        return false;
    }

    //“(xxx)yyy-zzzz”
    //Function: takes in user string sees if it matches format
    private boolean checkFormatThree(String userEnteredNumber)
    {
        if(userEnteredNumber.matches(".*(\\(\\d{3}\\)\\d{3}-\\d{4}).*"))
        {
            return true;
        }
        return false;
    }
}
