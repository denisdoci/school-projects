I did not achieve the runtime requirement. So be warned for the datasets I tested on
it ran for like 30 minutes. That being said if you want to test on smaller data 
sets it should be pretty easy to run. Assuming you have python already start in the 
environment, you can run it like any other python script. 

*** NOTE ***

Make sure whatever input file you use to test is in the same directory.



Ambiguously:

python ./subsetsum.py <N_MAX> <TARGET> <INPUT-FILE>

Example:

test all 50 in electoral for sum 24

python ./subsetsum.py 50 24 electoral.txt