
abstract public class animal {
	private boolean moved;
	private int x;
	private int y;
	private int dayLastMoved;
	private Island isl;

	public void move(){}
	public void breed(){}
}